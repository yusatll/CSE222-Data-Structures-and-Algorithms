package com.devdaily.imagetests;

public class PriorityQueue {

    public BinaryHeap heap;
    private int capacity;


    PriorityQueue(Comparator com ,int c)
    {
        capacity = c;
        heap = new BinaryHeap(com,c);
    }

    public synchronized int add(int p)
    {
        heap.add(p);
        return p;
    }

    public synchronized void printRGB(int p)
    {
        heap.printRGB(p);
    }

    public boolean isEmpty()
    {
        return heap.isEmpty();
    }

    public boolean isFull()
    {
        return heap.isFull();
    }

    public synchronized int remove ()
    {
        return heap.remove();
    }

    public int peek()
    {
        return heap.getFirst();
    }


}

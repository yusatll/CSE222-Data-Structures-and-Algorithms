package com.devdaily.imagetests;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

public class PQEUC implements Comparator<Integer> {

    @Override
    public int compare(Integer obj1, Integer obj2) {
        int red1 = (obj1 >> 16) & 0xff;
        int green1 = (obj1 >> 8) & 0xff;
        int blue1 = (obj1) & 0xff;

        int red2 = (obj2 >> 16) & 0xff;
        int green2 = (obj2 >> 8) & 0xff;
        int blue2 = (obj2) & 0xff;

        double cal1 = sqrt(pow(red1,2) + pow(green1,2) + pow(blue1,2));
        double cal2 = sqrt(pow(red2,2) + pow(green2,2) + pow(blue2,2));

        if (cal1 > cal2)
            return 1;
        else if(cal1 < cal2)
            return -1;
        else
            return 0;
    }
}

package com.devdaily.imagetests;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    private static int width;
    private static int height;

    public static void main(String[] args)
    {
        Comparator lex = new PQLEX();
        Comparator euc = new PQEUC();
        Comparator bmx = new PQBMX();
        int [][] photograph;
        BufferedImage image = null;

        String photo;        // = "example.png";

        System.out.println("Enter Photo's name : ");
        Scanner scanner = new Scanner(System.in);
        photo = scanner. nextLine();

        try
        {
            image = ImageIO.read(new FileInputStream(photo));
        }
        catch (IOException e)
        {
            System.out.println("Image Error.");
            System.err.println(e.getMessage());
        }

        width  = image.getWidth();
        height = image.getHeight();
        int size = width * height;

        PriorityQueue queueLex = new PriorityQueue(lex, size);
        PriorityQueue queueEuc = new PriorityQueue(euc, size);
        PriorityQueue queueBmx = new PriorityQueue(bmx, size);

        photograph = new int[height][width];

        for (int i = 0; i < height; i++)
        {
            for (int j = 0; j < width; j++)
            {
                int pixel = image.getRGB(j, i);
                photograph[i][j] = pixel;
            }
        }

        PC pc = new PC(queueLex,queueEuc,queueBmx);
        Producer p1 = new Producer(queueLex,queueBmx,queueEuc,photograph,pc);
        Consumer c1 = new Consumer(pc,photograph, 'L');
        Consumer c2 = new Consumer(pc,photograph, 'E');
        Consumer c3 = new Consumer(pc,photograph, 'B');

        p1.start();
        c1.start();
        c2.start();
        c3.start();

    }


    static class Producer extends Thread {
        private PC Pproducer;
        private int [][] photo;
        private PriorityQueue lexQ;
        private PriorityQueue bmxQ;
        private PriorityQueue eucQ;

        public Producer(PriorityQueue q1, PriorityQueue q2, PriorityQueue q3,int [][] ph, PC c)
        {
            Pproducer = c;
            lexQ = q1;
            eucQ = q2;
            bmxQ = q3;
            photo = ph;
        }

        public void run()
        {
            int hundredCheck=0;
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    hundredCheck++;
                    lexQ.add(photo[i][j]);
                    eucQ.add(photo[i][j]);
                    bmxQ.add(photo[i][j]);
                    System.out.print("Thread-1 ");
                    lexQ.printRGB(photo[i][j]);
                    Pproducer.put(hundredCheck);
                }
            }
        }
    }


    static class Consumer extends Thread
    {
        private PC pconsumer;
        private char type;
        private int [][] photo;

        public Consumer(PC c ,int [][] p, char ch) {
            pconsumer = c;
            type = ch;
            photo = p;
        }

        public void run()
        {
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    pconsumer.get(photo[i][j], type);
                }
            }
        }
    }
}



package com.devdaily.imagetests;

public class PC
{
    private PriorityQueue lexQueue;
    private PriorityQueue bmxQueue;
    private PriorityQueue eucQueue;
    private boolean contCheck = false;
    private final int N = 100;

    /**
     * we need take all comparator class queues for add and remove pixel.
     * @param l lex
     * @param e euc
     * @param b bmx
     */
    public PC(PriorityQueue l, PriorityQueue e, PriorityQueue b) {
        lexQueue = l;
        bmxQueue = b;
        eucQueue = e;
    }

    /**
     *
     * we check for one hundred pixel. to notify other threads
     * @param value pixel counter.
     */
    public synchronized void put(int value)
    {
        if (value >= N)
        {
            contCheck = true;
            notifyAll();
        }
        else
            contCheck = false;

    }

    /**
     * print the pixel for different comparator class.
     * @param value this pixel
     * @param c comparator class type.
     */
    public synchronized void get(int value,char c)
    {
        while (!contCheck)
        {
            try
            {
                wait();
            }
            catch (InterruptedException i) {}
        }

        if(c == 'l' || c == 'L')
        {
            if(lexQueue.isEmpty())
            {
                try
                {
                    wait();
                }
                catch (InterruptedException i) {}
            }
            else
            {
                System.out.print("Thread-2 ");
                lexQueue.printRGB(value);
                lexQueue.remove();
                contCheck = true;
            }
        }
        else if (c == 'b' || c == 'B')
        {
            if (bmxQueue.isEmpty())
            {
                try
                {
                    wait();
                }
                catch (InterruptedException i) {}
            }
            else
            {
                System.out.print("Thread-4 ");
                bmxQueue.printRGB(value);
                bmxQueue.remove();
                contCheck = true;
            }
        }
        else if (c == 'e' || c == 'E')
        {
            if (eucQueue.isEmpty())
            {
                try
                {
                    wait();
                }
                catch (InterruptedException i) {}
            }
            else
            {
                System.out.print("Thread-3 ");
                eucQueue.printRGB(value);
                eucQueue.remove();
                contCheck = true;
            }
        }
    }
}
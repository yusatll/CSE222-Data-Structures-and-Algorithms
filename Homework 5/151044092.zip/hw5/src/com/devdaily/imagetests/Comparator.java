package com.devdaily.imagetests;

public interface Comparator<T> {
    int compare(T obj1, T obj2);
}

package com.devdaily.imagetests;

public class PQBMX implements Comparator<Integer> {

    @Override
    public int compare(Integer obj1, Integer obj2)
    {
        int cmp1=0, cmp2=0;

        int red1 = (obj1 >> 16) & 0xff;
        int green1 = (obj1 >> 8) & 0xff;
        int blue1 = (obj1) & 0xff;

        int red2 = (obj2 >> 16) & 0xff;
        int green2 = (obj2 >> 8) & 0xff;
        int blue2 = (obj2) & 0xff;

        for (int i = 7; i > 1; i--)
        {
            cmp1 = (red1 >> 7) & 1;
            cmp1 = cmp1 << 1;
            cmp1 = (green1 >> 7) & 1;
            cmp1 = cmp1 << 1;
            cmp1 = (blue1 >> 7) & 1;
            cmp1 = cmp1 << 1;

            cmp2 = (red2 >> 7) & 1;
            cmp2 = cmp2 << 1;
            cmp2 = (green2 >> 7) & 1;
            cmp2 = cmp2 << 1;
            cmp2 = (blue2 >> 7) & 1;
            cmp2 = cmp2 << 1;
        }

        if(cmp1 > cmp2)
            return 1;
        else if(cmp1 < cmp2)
            return -1;
        else return 0;

    }

}

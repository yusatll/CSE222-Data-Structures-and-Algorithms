package com.devdaily.imagetests;

public class PQLEX implements Comparator<Integer> {

    @Override
    public int compare(Integer obj1, Integer obj2) {
        int red1 = (obj1 >> 16) & 0xff;
        int green1 = (obj1 >> 8) & 0xff;
        int blue1 = (obj1) & 0xff;

        int red2 = (obj2 >> 16) & 0xff;
        int green2 = (obj2 >> 8) & 0xff;
        int blue2 = (obj2) & 0xff;

        if (red1 > red2)
            return 1;
        else if (red1 < red2 )
            return -1;

        if (green1 > green2)
            return 1;
        else if (green1 < green2 )
            return -1;

        if (blue1 > blue2)
            return 1;
        else if (blue1 < blue2 )
            return -1;
        else
            return 0;

    }
}

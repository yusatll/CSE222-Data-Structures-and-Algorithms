package com.devdaily.imagetests;
import java.util.NoSuchElementException;

public class BinaryHeap
{
    private static int capacity;
    private int[] heap;
    private int heapSize;

    private Comparator comparator;

    public BinaryHeap(Comparator com,int cap)
    {
        comparator = com;
        capacity = cap;
        heap = new int[capacity + 1];
        heapSize = 0;
    }
    public BinaryHeap(int cap)
    {
        capacity = cap;
        heap = new int[capacity + 1];
        heapSize = 0;
    }

    public int getFirst()
    {
        return heap[0];
    }
    public boolean isEmpty()
    {
        return heapSize == 0;
    }

    public boolean isFull()
    {
        return heapSize == heap.length;
    }

    private int parentIndex(int i)
    {
        return (i - 1)/2;
    }

    private int kChild(int i, int k)
    {
        return 2 * i + k;
    }

    public synchronized int add(int x)
    {
        if (isFull())
            throw new NoSuchElementException("Overflow Exception");

        int index = heapSize;
        heap[heapSize] = x;
        //while (heap[parentIndex(index)] > heap[index] && index != 0)
        while (heapSize != 0 && comparator.compare(heap[parentIndex(index)],heap[index]) == 1)
        {
            swap(index,parentIndex(index));
            index = parentIndex(index);
        }

        heapSize++;
        return x;
    }

    public synchronized int remove()
    {
        int popped,m;
        if (isEmpty())
            throw new NoSuchElementException("UnderFlow Exception");

        int index = 0;
        int lih = heap[heapSize-1];
        popped = heap[0];
        heap[0] = lih;

        while (comparator.compare(lih, heap[m = minChildIndex(index)]) == 1 && hasChild(m))
        {
            swap(index,m);
            index = m;
            lih = heap[index];
        }
        heapSize--;
        return popped;
    }

    private boolean hasChild(int index)
    {
        if (heap[2*index+1] != 0 || heap[2*index+2] != 0)
            return true;
        return false;
    }

    private int minChildIndex(int index)
    {
        if (heap[2*index +1] > heap[2*index+2])
            return 2*index+2;
        else
            return 2*index+1;
    }


    private int minChild(int a)
    {
        int child1 = kChild(a,1);
        int t = 2;
        int index = kChild(a,t);

        while ((t <= 2) && index < heapSize)
        {
            if(heap[index] < heap[child1])
                child1 = index;
            index = kChild(a,t++);
        }
        return child1;
    }


    public void printHeap()
    {
        System.out.print("\nHeap = ");
        for (int i = 0; i < heapSize; i++)
            System.out.print(heap[i] +" ");
        System.out.println();
    }

    private void swap(int pos1, int pos2)
    {
        int tmp;
        tmp = heap[pos1];
        heap[pos1] = heap[pos2];
        heap[pos2] = tmp;
    }

    public void printRGB(int pixel) {
        //int alpha = (pixel >> 24) & 0xff;
        int red = (pixel >> 16) & 0xff;
        int green = (pixel >> 8) & 0xff;
        int blue = (pixel) & 0xff;
        System.out.println(" [ " + red + ", " + green + ", " + blue + " ]");
    }

}
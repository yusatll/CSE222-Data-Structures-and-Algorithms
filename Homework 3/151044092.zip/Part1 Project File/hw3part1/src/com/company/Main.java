package com.company;

import javax.swing.*;
import java.io.*;

public class Main {

    public static boolean[][] visited;
    static public int ROW;
    static public int COL;
    public static void main(String[] args) throws IOException {

        int[][] matrix = null;
        ArrayStack<Integer> theData = null;

        FileReader fr = new FileReader("test1");
        FileReader lfr = new FileReader("test1");
        BufferedReader br = new BufferedReader(fr);
        LineNumberReader lnr = new LineNumberReader(lfr);
        int x=0;
        String line;

        // find the lines in file.
        int lineNumbers =0;
        while(lnr.readLine() != null)
            lineNumbers++;


        ROW = lineNumbers;

        while( (line = br.readLine()) != null) {
            String[] numbers = line.split(" ");

            if(matrix == null) {
                COL = numbers.length;
                matrix = new int[ROW][COL];
            }
            for (int i=0; i< numbers.length; i++) {
                int y =  Integer.parseInt(numbers[i]);
                matrix[x][i] = y;
            }
            x++;
        }

        br.close();
        lnr.close();

        visited = new boolean[ROW][COL];

        for (int i=0;i<matrix.length;i++)
            for (int j = 0; j < matrix[i].length; j++)
                visited[i][j] = false;

        int labcount=0;
        for (int i=0;i<matrix.length;i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == 1 && !visited[i][j]) {
                    useStack(matrix, i, j);
                    labcount++;
                }
            }
        }


    System.out.println("LABELS : "+labcount);

    }

    /**
     * this function using stack. find "1" in matrix and push the stack.
     * and then find top, left, right and bottom "1". end of search pop the last one.
     * and using last coordinates find others neighbour.
     * @param matrix the islands in the file
     * @param r current row in matrix
     * @param c current column in matrix
     */

    static void useStack(int [][]matrix, int r, int c)
    {
        ArrayStack<Coordinates> stack = new ArrayStack<>();
        Coordinates popCoor;
        int rowNbr[] = new int[] { -1, 0, 0, 1};
        int colNbr[] = new int[] { 0, -1, 1, 0};

        boolean loop = true;
        while(loop) {
            for (int i = 0; i < 4; i++) {
                if (checkPossibility(matrix, r + rowNbr[i], c + colNbr[i])) {
                    visited[r + rowNbr[i]][c + colNbr[i]] = true;
                    stack.push(new Coordinates(r + rowNbr[i], c + colNbr[i]));
                }
            }
            if (!stack.isEmpty()) {
                popCoor = stack.pop();
                r = popCoor.r;
                c = popCoor.c;
                loop = true;
            }
            else
                loop = false;

        }
    }

    /**
     * check the current coordinates. if it is possible to search it.
     * @param M the matrix
     * @param row current row
     * @param col current column
     * @return
     */
    static boolean checkPossibility(int M[][], int row, int col)
    {
        return (row >= 0) && (row < ROW) && (col >= 0) && (col < COL) &&
                (M[row][col]==1 && !visited[row][col]);
    }


}

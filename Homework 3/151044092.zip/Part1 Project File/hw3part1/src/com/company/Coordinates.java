package com.company;

public class Coordinates {
    public int r;
    public int c;
    Coordinates(int a, int b)
    {
        r = a;
        c = b;
    }
}

package com.company;

public class ArrayStack<T> implements StackInterface<T>
{
    private T[] stack; // array of stack entries
    private int topIndex; // index of top entry
    public int getTop() { return topIndex; }
    private static final int DEFAULT_INITIAL_CAPACITY = 50;
    public ArrayStack()
    {
        this(DEFAULT_INITIAL_CAPACITY);
    } // end default constructor



    public ArrayStack(int initialCapacity)
    {
        // the cast is safe because the new array contains null entries
        @SuppressWarnings("unchecked")
        T[] tempStack = (T[])new Object[initialCapacity];
        stack = tempStack;
        topIndex = -1;
    }


    @Override
    public void push(T newEntry)
    {
        if (topIndex == stack.length - 1) { // if array is full
            ensureCapacity();
        }
        topIndex++;
        stack[topIndex] = newEntry;
    } // end push

    private void ensureCapacity() {
        @SuppressWarnings("unchecked")
        T[] tempStack = (T[])new Object[stack.length];
        System.out.println("ensurecap");
        for (int i=0; i<stack.length; i++) {
            tempStack[i] = stack[i];
            System.out.println("temps "+tempStack[i]);
        }

        stack = (T[])new Object[2*tempStack.length];

        for (int j=0; j< 2*tempStack.length; j++)
            stack[j] = tempStack[j];

    } // end ensureCapacity

    @Override
    public T pop()
    {
        T top = null;
        if (!isEmpty())
        {
            top = stack[topIndex];
            stack[topIndex] = null;
            topIndex--;
        }
        return top;
    } // end pop

    @Override
    public T peek()
    {
        T top = null;
        if (!isEmpty())
            top = stack[topIndex];
        return top;
    }

    @Override
    public boolean isEmpty() {
        return topIndex < 0;
    }

    @Override
    public void clear() {
        while(topIndex>=0)
            this.pop();
    }

    public void print()
    {
        while(topIndex>=0)
            System.out.println(this.pop());
    }
} // end ArrayStack
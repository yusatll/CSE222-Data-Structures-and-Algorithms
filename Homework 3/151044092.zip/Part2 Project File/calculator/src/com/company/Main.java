package com.company;

import java.io.*;
import java.util.Objects;
import java.util.Spliterator;
import java.util.StringTokenizer;


public class Main {
    public static double PI = 3.14159265359;
    static String [] variables;
    static double[] inputs;
    public static void main(String[] args) throws IOException {

        FileReader fr = new FileReader("test");
        FileReader lfr = new FileReader("test");
        BufferedReader br = new BufferedReader(fr);
        LineNumberReader lnr = new LineNumberReader(lfr);
        StringTokenizer st = null;

        String line;

        // find the lines in file.
        int lineNumbers =0;
        while(lnr.readLine() != null)
            lineNumbers++;

        inputs = new double[lineNumbers-2];
        int n=0,m=0,k=0;
        boolean var = false;
        boolean isInt = true;

        variables = new String[lineNumbers-2];
        String []tokens = null;
        String oper = null;
        while(n<lineNumbers)
        {
            line = br.readLine();
            st = new StringTokenizer(line);
            if(line.length() == 0)
                var = true;
            if(!var) {
                // find the variables values.
                while (st.hasMoreTokens()) {
                    String num = st.nextToken("=");
                    //System.out.println("tk " + num);
                    isInt = true;
                    try {
                        Integer.parseInt(num);
                    }catch (NumberFormatException e){
                        //System.out.println("not int");
                        variables[k] = num;
                        k++;
                        isInt = false;
                    }

                    if(isInt) {
                        //System.out.println("is int");
                        inputs[m] = Integer.parseInt(num);
                        m++;
                    }
                }
            }
            else
            {
                // infix calculate.
                //System.out.println("son satır." + line);
                if(line.length() > 1) {
                    tokens = new String[line.length()];
                    tokens = line.split("\\s+");
                }
            }
            n++;
        }
        StringBuilder sb = new StringBuilder();
        for (int i=0; i < tokens.length; i++)
        {
            sb.append(tokens[i]);
            //System.out.println("tok: "+tokens[i]);
            //oper += tokens[i];
        }
        oper = sb.toString();
        System.out.println("Operation : " + oper);
        String post = convertToPostfix(oper);
        System.out.println("Postfix : "+post);
        System.out.println("Calculate " + evaluate(post));

    }


    public static String convertToPostfix(String infix) {
        ArrayStack<String> operatorStack = new ArrayStack<String>();
        char c;
        StringTokenizer parser = new StringTokenizer(infix,"+-*/^() ",true);
        StringBuffer postfix = new StringBuffer(infix.length());
        String token = "";
        while (parser.hasMoreTokens()) {
            token = parser.nextToken();
            c = token.charAt(0);
            if ( (token.length() == 1) && isOperator(c) ) {
                while (!operatorStack.isEmpty() &&
                        !findPrecedence(((String)operatorStack.peek()).charAt(0), c))

                    postfix.append(" ").append((String)operatorStack.pop());
                if (c==')') {
                    String operator = (String)operatorStack.pop();
                    while (operator.charAt(0)!='(') {
                        postfix.append(" ").append(operator);
                        operator = (String)operatorStack.pop();
                    }
                }
                else
                    operatorStack.push(token);
            }
            else if ( (token.length() == 1) && isSpace(c) ) { /*do nothing*/ }
            else if("sin".equals(token) || "abs".equals(token) || "cos".equals(token)){

                int choose =0;
                if ("sin".equals(token))
                    choose = 1;
                else if ("cos".equals(token))
                    choose = 2;
                else
                    choose = 3;

                String inside = "";
                while (!Objects.equals(token,")"))
                {
                    token = parser.nextToken();
                    inside += token;
                }
                String str = convertToPostfix(inside);
                double a =0;
                double s=0;
                if (choose == 1) {
                    a = evaluate(str);
                    s = sin(a);
                }
                else if (choose == 2) {
                    a = evaluate(str);
                    s = cos(a);
                }
                else {
                    str = str.replaceAll("-","");

                    try {
                        //a = evaluate(str);
                        a = Double.parseDouble(str);
                    }
                    catch(NumberFormatException n){
                        //System.out.println("not double");
                    }
                    s = abs(a);

                }
                postfix.append(" ").append(s);
            }
            else {
                postfix.append(" ").append(token);
            }
        }
        while (!operatorStack.isEmpty())
            postfix.append(" ").append((String)operatorStack.pop());

        return postfix.toString();
    }

    private static boolean isSpace(char c) { return (c == ' '); }


    static double evaluate(String expr) {

        ArrayStack<Double> stack = new ArrayStack<Double>();
        double op1, op2;
        double result;
        String token;
        StringTokenizer tokenizer = new StringTokenizer(expr);
        double val=0;

        while (tokenizer.hasMoreTokens()) {
            token = tokenizer.nextToken();
            char c = token.charAt(0);
            if (isInteger(token))
            {
                try{
                    Double.parseDouble(token);
                }
                catch (NumberFormatException n){
                    //System.out.println("is not int");
                }
                stack.push(Double.valueOf(token));
            }
            else if (isOperator(c)) {
                op2 = (stack.pop());
                op1 = (stack.pop());
                result = evalSingleOp(token.charAt(0), op1, op2);
                //System.out.println("res " + result + " op1 "+op1+" op2 "+op2+" oper "+token.charAt(0));
                stack.push(result);
            }
            else{
                val = valInputs(token);
                //System.out.println("not int val " + val +" token " +token);
                stack.push(val);
            }
        }
        result = (stack.pop()).intValue();
        return result;
    }

    public static double valInputs(String s)
    {
        double r=0;
        for (int i=0;i<variables.length;i++) {
            if (variables[i].equals(s))
                r = inputs[i];
        }
        return r;
    }

    private static double evalSingleOp(char operation, double op1, double op2) {
        double result = 0;

        switch (operation) {
            case '+' :
                result = op1 + op2;
                break;
            case '-' :
                result = op1 - op2;
                break;
            case '*' :
                result = op1 * op2;
                break;
            case '/' :
                result = op1 / op2;
        }

        return result;
    }
    private static boolean findPrecedence(char op1, char op2)
    {
        switch (op1)
        {
            case '+':
            case '-':
                return !(op2 == '+' || op2 == '-');

            case '*':
            case '/':
                return op2 == '^' || op2 == '(';

            case '^':
                return op2 == '(';

            case '(':
                return true;

            default:
                return false;
        }
    }

    private static boolean isInteger(String  c)
    {
        try{
            Double.parseDouble(c);
        }
        catch (NumberFormatException n)
        {
            return false;
        }
        return true;
    }

    private static boolean isOperator(char c)
    {
        return (!(c >= 'a' && c <= 'z') &&
                !(c >= '0' && c <= '9') &&
                !(c >= 'A' && c <= 'Z') ); //&& !(c == '.')
    }

    static double sin(double x)
    {
        x = x % (2 * PI);

        double term = 1.0;
        double sum  = 0.0;

        for (int i = 1; term != 0.0; ++i)
        {
            term *= (x / i);

            if (i % 4 == 1)
            {
                sum += term;
            }
            if (i % 4 == 3)
            {
                sum -= term;
            }
        }
        return sum;
    }

    static double abs(double x)
    {
        if (x < 0.0)
        {
            x *= -1;
        }
        return x;
    }

    static double cos(double x)
    {
        x = x % (2 * PI);

        double term = 1.0;
        double sum  = 1.0;

        for (int i = 1; term != 0.0; i++)
        {
            term *= (x / i);

            if (i % 4 == 0)
            {
                sum += term;
            }
            if (i % 4 == 2)
            {
                sum -= term;
            }
        }
        return sum;
    }

}

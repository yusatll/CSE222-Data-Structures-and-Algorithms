public class iteratorRec {

    private int [] arrayD;
    private int size=0;

    private int index=0;
    iteratorRec()
    { }

    boolean hasNext()
    {
        return size > index;
    }

    int next()
    {
        return arrayD[index++];
    }

    private int currentrow=0,currentcol=0;
    private int minrow, mincol,totalnum;

    void traverse(int [][] data,int r, int c)
    {
        totalnum = r*c;
        arrayD = new int[totalnum];
        currentcol = c;
        currentrow = r;
        mincol = 0;
        minrow = 0;
        traverse2D(data,minrow,mincol,currentrow-1,currentcol-1);
    }

    private void traverse2D(int[][] theData, int startRow, int startCol, int maxRow, int maxCol)
    {
        /* go to right size */
        for (int i = startRow; i <= maxCol; i++)
        {
            arrayD[size++] = theData[startRow][i];
        }

        /* go to bottom */
        for (int i = startRow+1; i <= maxRow; i++)
        {
            arrayD[size++] = theData[i][maxCol];
        }

        /* go to left */
        if(startRow+1 <= maxRow)
        {
            for (int i = maxCol-1; i >= startCol; i--)
            {
                arrayD[size++] = theData[maxRow][i];
            }
        }

        /* go up */
        if(startCol+1 <= maxCol)
        {
            for (int i = maxRow-1; i > startRow; i--)
            {
                arrayD[size++] = theData[i][startCol];
            }
        }
        /* recursive call */

        if(startRow+1 <= maxRow-1 && startCol+1 <= maxCol-1){
            traverse2D(theData, startRow+1, startCol+1, maxRow-1, maxCol-1);
        }
    }

    void printdata()
    {
        for (int i=0;i<size;i++) {
            System.out.print(arrayD[i] + " ");

        }
    }
}

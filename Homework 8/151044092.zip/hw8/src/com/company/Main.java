package com.company;


public class Main {

    public static void main(String[] args) throws Exception {
        ListGraph ag = new ListGraph("input.txt");
        ag.findPopular();
    }
}

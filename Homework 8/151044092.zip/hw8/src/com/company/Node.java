package com.company;

class Node
{
    private int source;
    private int dest;
    private Node next;

    Node(int s, int d)
    {
        source = s;
        dest = d;
    }

    Node(int d) {
        this.next.setDest(d);
    }

    public boolean equals(Object o)
    {
        Node e = (Node) o;
        if (this.dest == e.dest &&  this.source == e.source)
            return true;
        return false;
    }


    public void setNext(Node n) {
        this.next = n;
    }
    public Node getNext() {
        return this.next;
    }

    public int getDest() {
        return dest;
    }

    public void setDest(int dest) {
        this.dest = dest;
    }

    public int getSource() {
        return source;
    }

    public void setSource(int source) {
        this.source = source;
    }
}

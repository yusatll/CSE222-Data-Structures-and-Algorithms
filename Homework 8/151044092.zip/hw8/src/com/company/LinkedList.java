package com.company;

public class LinkedList
{
    private Node head = null;
    private int size=0 ;

    public LinkedList add(Node data)
    {
        if (this.head == null) {
            this.head = data;
        }
        else
        {
            Node ls = this.head;
            while (ls.getNext() != null) {

                ls = ls.getNext();
            }
            ls.setNext(data);
            //System.out.println("ls " + ls.getSource() + " "+ ls.getDest());
            //System.out.println("next " + ls.getNext().getSource() + " " + ls.getNext().getDest());
        }
        size++;
        return this;
    }

    public void add(int data)
    {
        Node ls = head;
        while (ls.getNext() != null)
            ls = ls.getNext();

        ls.setNext(new Node(data));
        size++;
    }

    public Node getNode(int index)
    {
        Node node = head;
        for (int i = 0; i < index && node != null; i++) {
            node = node.getNext();
        }
        return node;
    }

    public Node get(int index)
    {
        Node node = null;
        if (!(index < 0 || index >= size)) {
            node = getNode(index);
        }
        return node;
    }


    public Node getEdge(Node edge)
    {
        Node tempH = head;
        while(tempH != null)
        {
            if(tempH.getSource() == edge.getSource())
                return tempH;
        }
        return null;
    }


    public boolean contains(Node edge)
    {
        Node tempH = head;
        while(tempH != null)
        {
            if(tempH.getSource() == edge.getSource()
                && tempH.getDest() == edge.getDest())
                return true;
        }
        return false;
    }

    public void print()
    {
        Node c = head;
        while (c != null)
        {
            System.out.println(c.getSource() + " -> " + c.getDest());
            c = c.getNext();
        }
    }

    public int getSize(){
        return size;
    }
}
package com.company;

public class AbstractGraph {

    private int numV;
    private boolean directed;

    public AbstractGraph() {
    }


    public boolean isDirected()
    {
        return directed;
    }
    public int getNumV() { return numV; }

    public AbstractGraph(int numV, boolean directed)
    {
        this.numV = numV;
        this.directed = directed;
    }

}

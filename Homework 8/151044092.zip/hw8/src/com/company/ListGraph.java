package com.company;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ListGraph extends AbstractGraph {

    private LinkedList[] edges;
    private int[] popularity;

    private int NumberOfPeople;
    private int OrderedRel;
    private int size =0;


    public ListGraph(int numV, boolean directed) {
        //super(numV, directed);

        edges = new LinkedList[numV];
        for (int i = 0; i < numV; i++) {
            edges[i] = new LinkedList();
        }
    }

    public ListGraph(String filename) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filename));
        loadEdgesFromFile(br);
    }

    public boolean isEdge(int source, int dest) {
        return edges[source].contains(new Node(source,dest));
    }

    private void insert(Node edge) {
        edges[edge.getSource()].add(edge);
        //edges[size].add(edge);
        size++;
    }

    public Node getEdge(int source, int dest)
    {
        Node target = new Node(source,dest );   // Double.POSITIVE_INFINITY
        int j=0;
        for (int i=0; i< NumberOfPeople; i++) {
            if (edges[i].contains(target))
                return (Node) edges[i].getEdge(target);
        }

        /*
        for(Edge e : edges[source])
        {
            if (e.equals(target))
                return e;
        }
        */
        return target;
    }


    private void loadEdgesFromFile(BufferedReader br) throws IOException
    {
        String line;
        line = br.readLine();
        Scanner scanner = new Scanner(line);
        NumberOfPeople = scanner.nextInt();
        OrderedRel = scanner.nextInt();

        edges = new LinkedList[NumberOfPeople*3];
        popularity = new int[NumberOfPeople*3];

        for (int i = 0; i < NumberOfPeople*3; i++) {
            edges[i] = new LinkedList();
        }

        while((line = br.readLine()) != null && line.length() != 0)
        {
            scanner = new Scanner(line);
            int source = scanner.nextInt();
            int dest = scanner.nextInt();
            //edges[source] = new LinkedList();

            insert(new Node(source,dest));
        }
    }

    public void findPopular()
    {
        System.out.println("BEFORE TRANSITIVE");
        printL();
        System.out.println();
        transitive();
        System.out.println();
        System.out.println("AFTER TRANSITIVE");
        printL();
        popi();
        System.out.println();
        //printP();
        countPop();
    }

    private void transitive()
    {
        //System.out.println("transitive ");
        for (int i = 0; i < edges.length; i++)
        {
            //System.out.println("sizee " + edges[i].getSize());
            for (int j = 1; j <= edges[i].getSize(); j++) {
                //System.out.println("i " + i + " j " + j);
                findInLL(edges[i],edges[j].get(0));
            }
        }
    }
    private void findInLL(LinkedList list,Node node)
    {
        // list : 2-1 , 2-3
        // node : 1-2
        //System.out.print("list");
        //list.print();
        //System.out.println("node " + node.getSource() + " "+node.getDest());
        for (int i = 0; i < list.getSize(); i++) {
            if (list.getNode(i).getSource() == node.getDest() &&
                    node.getSource() != list.getNode(i).getDest()){
                //System.out.println("list "+list.getNode(i).getSource() + "  " + list.getNode(i).getDest());
                //System.out.println("node " + node.getSource() + " " + node.getDest());
                insert(new Node(node.getSource(),list.getNode(i).getDest()));
            }

        }
    }
    private void printL() {
        System.out.println("GRAPH : ");
        for (int i = 0; i < edges.length; i++) {
            edges[i].print();
        }
    }

    private void popi()
    {
        for (int i = 0; i < edges.length; i++)
            findPop(edges[i]);
    }

    private void findPop(LinkedList list)
    {
        //System.out.println("FINDPOP "+list.getSize());
        for (int i = 0; i < list.getSize(); i++) {
            //System.out.println(list.getNode(i).getSource()+" "+list.getNode(i).getDest());
            if (list.getNode(i) != null) {
                int index = list.getNode(i).getDest();
                //System.out.println("index "+index);
                popularity[index]++;
            }
        }
    }

    private int countPop()
    {
        int max=-1,count=0;
        for (int i = 0; i < popularity.length; i++) {
            if (popularity[i] > max){
                max = popularity[i];
                count = 0;
            }
            if (popularity[i] == max)
                count++;
        }

        System.out.println("RESULT POPULAR : "+ count);
        return count;
    }

    private void printP() {
        //System.out.println("Pop : ");
        for (int i = 0; i < popularity.length; i++) {
            System.out.println(popularity[i]);
        }
    }

}
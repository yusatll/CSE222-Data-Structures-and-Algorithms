package com.company;

import static java.lang.String.format;

public class Experiment {


    private String setup;
    private int day;
    private String time;
    private boolean completed;
    private float accuracy;

    public Experiment next;
    public Experiment nextDay;


    public Experiment(int d)
    {
        //setup = "explains the experimental setup";
        day = d;
        completed = false;
        next = null;
        nextDay = null;
    }

    public Experiment(Experiment e1)
    {
        this.setup = e1.getSetup();
        this.day = e1.getDay();
        this.time = e1.getTime();
        this.completed = e1.isCompleted();
        this.accuracy = e1.getAccuracy();
        this.next = e1.next;
        this.nextDay = e1.nextDay;
    }

    public Experiment(String s, int d, String t, boolean com, float ac)
    {
        this.setup = s;
        this.day = d;
        this.time = t;
        this.completed = com;
        this.accuracy = ac;
    }

    public Experiment() {
        next = null;
        nextDay = null;
    }

    public void printEx()
    {
        System.out.println("Setup : " + this.getSetup()
                            + " Day: : " + this.getDay()
                            //+" Time : "  + this.getTime()
                            //+ " Completed : " + this.isCompleted()
                            + " Accuracy : " + this.getAccuracy()  );
    }

    public String getSetup() { return setup; }
    public int getDay(){ return day; }
    public String getTime() { return time; }
    public boolean isCompleted() { return completed; }
    public float getAccuracy() { return accuracy; }

    public void setAccuracy(float accuracy) {
        this.accuracy = accuracy;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public void setNext(Experiment next) {
        this.next = next;
    }

    public void setNextDay(Experiment nextDay) {
        this.nextDay = nextDay;
    }

    public void setSetup(String setup) {
        this.setup = setup;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String toString()
    {
        return format("result %s \t %d \t %s \t %s \t %f",this.setup,this.day, this.time, this.completed, this.accuracy);
    }
}

package com.company;

import java.util.Iterator;
import java.util.NoSuchElementException;

import static java.lang.System.exit;

/**
 *
 */
public class ExperimentList implements Iterable<Experiment> {

    public Experiment head = null;
    public Experiment endoflist = new Experiment();
    public Experiment endoflisttemp = new Experiment();
    public int Gsize;
    public Iterable<Experiment> iterator;

    /**
     * this function create a linked list.
     * @param ex this parameter is Experiment. We should add ex to end of day.
     */
    public void addExp(Experiment ex) // insert experiment to the end of the day
    {

        if (head == null) {
            head = ex;
        }
        else {
            endoflist = head;
            endoflisttemp = head;
            if(ex.getDay() < head.getDay()) //önceki gün exp gelirse. endoflist o olacak.
            {
                head = ex;
                head.next =  endoflist;
            }
            else if (ex.getDay() ==  head.getDay()){

                while (endoflist.next != null){
                    if (endoflist.next.getDay() != ex.getDay())
                        break;
                    endoflist = endoflist.next;
                }

                ex.next = endoflist.next;
                endoflist.next = ex;
            }
            else if (ex.getDay() > head.getDay())
            {

                while (endoflist.next != null){
                    if (endoflist.getDay() >= ex.getDay())
                        break;
                    endoflisttemp = endoflist; // endoflist den  önceki elemanı alıyoruz.
                    endoflist = endoflist.next;
                }

                if(endoflist.getDay() == ex.getDay()) {

                    while (endoflist.next != null) {
                        if (endoflist.next.getDay() != ex.getDay())
                            break;
                        endoflist = endoflist.next;
                    }
                    // en sona aynı gün ekleme
                    ex.next = endoflist.next;
                    endoflist.next = ex;
                }
                else if (endoflist.getDay() > ex.getDay())
                {
                    ex.next = endoflist;
                    endoflisttemp.next = ex;
                }
                else
                {
                    endoflist.next = ex;
                    ex.next = null;
                }
            }
        }
    }



    /**
     *  get the experiment with the given day and position.
     *  This function gives you an Experiment object if this day and index have a Experiment.
     *  if day or index are not found, it returns Error and exit.
     * @param day take the given day.
     * @param index  go to this index in this day
     * @return  return an experiment to user.
     */
    public Experiment getExp(int day, int index)
    {
        endoflist = head;
        while(endoflist.next != null) {
            if(endoflist.getDay() == day)
                break;
            endoflist = endoflist.next;
        }

        if(endoflist.getDay() > day) {
            System.out.println("This Day Not Found");
            //throw new NoSuchElementException();
            exit(1);
        }
        // sonraki gün yoksa ve belirtilen güne ulaşamadıysak. Error.
        if(endoflist.nextDay == null && endoflist.getDay() != day) {
            System.out.println("This Day Not Found.");
            exit(1);
            //throw new NoSuchElementException();
        }
        int i;
        for (i=1; i < index; i++)
        {
            // next ilerlerken day değişirse. aradığımız yok. Error.
            if(endoflist.next.getDay() != day ) {
                System.out.println("This Index Not Found.");
                exit(1);
                //throw new NoSuchElementException();
            }
            else
                endoflist = endoflist.next;
        }
        if(endoflist.getDay() == day && i == index)
            endoflist.printEx();
        return endoflist;

    }

    /**
     *  set the experiment with the given day and position.
     *  This function set given Experiment to this day and index.
     * @param day go to the given day.
     * @param index find given day's index.
     * @param e copy this experiment to day and index.
     */
    public void setExp(int day, int index, Experiment e)
    {
        endoflist = head;
        endoflisttemp = endoflist;
        while(endoflist.next != null) {
            if(endoflist.getDay() == day)
                break;
            endoflisttemp = endoflist;
            endoflist = endoflist.next;
        }

        if(endoflist.getDay() > day) {
            System.out.println("gün bulunamadı");
            //throw new NoSuchElementException();
            exit(1);
        }
        // sonraki gün yoksa ve belirtilen güne ulaşamadıysak. Error.
        if(endoflist.nextDay == null && endoflist.getDay() != day) {
            System.out.println("Girilen gün bulunamadı.");
            exit(1);
            //throw new NoSuchElementException();
        }
        int i;
        for (i=1; i < index; i++)
        {
            // next ilerlerken day değişirse. aradığımız yok. Error.
            if(endoflist.next.getDay() != day ) {
                System.out.println("aynı günde başka next yok. index bulunamadı.");
                exit(1);
                //throw new NoSuchElementException();
            }
            else {
                endoflisttemp = endoflist;
                endoflist = endoflist.next;
            }
        }
        if(endoflist.getDay() == day && i == index) {
            e.next = endoflist.next;
            e.nextDay = endoflist.nextDay;
            endoflisttemp.next = e;
        }
    }

    /***
     *
     * @param day go to this day
     * @param index go to this index.
     */
    public void removeExp(int day, int index) // remove the experiment specified as index from given day
    {
        boolean found = false;
        endoflist = head;
        endoflisttemp = head;
        try
        {
            while(endoflist.next != null) {
                if(endoflist.getDay() == day)
                    found = true;
                endoflist = endoflist.next;
            }
            if (!found)
                throw new NoSuchElementException();
        }catch (Exception e)
        {
            System.out.println("This Day Not Found.");
            exit(1);
        }

        endoflist = head;
        while (endoflist.next.getDay() < day )
        {
            endoflist = endoflist.next;
        }

        int i;
        for (i=1; i <= index; i++) {
            //endoflist.printEx();
            // next ilerlerken day değişirse. aradığımız yok. Error.
            if (endoflist.next == null) {
                System.out.println("This Index Not Found.");
                exit(1);
            } else if (endoflist.next.getDay() != day) {
                System.out.println("This Index Not Found..");
                exit(1);
                //throw new NoSuchElementException();
            } else {
                endoflisttemp = endoflist;
                endoflist = endoflist.next;
            }
        }
        //endoflisttemp.printEx();
        if(endoflist.nextDay != null)
            endoflist.next.nextDay = endoflist.nextDay;
        endoflisttemp.next = endoflist.next;
        //endoflist.printEx();
    }

    /***
     *
     * @param day list all experiments in this day.
     */
    public void listExp(int day) // list all completed experiments in a given day
    {
        endoflist = head;
        endoflisttemp = endoflist.next;
        while (endoflist.next.getDay() < day )
        {
            endoflist = endoflist.next;
        }
        //endoflist.printEx();
        if(endoflist.next.getDay() != day)
        {
            //System.out.println("endoflist nextin day" + endoflist.next.getDay());
            System.out.println("gün bulunmadı.");
            exit(1);
        }
        //endoflist = endoflisttemp;
        if(endoflist != head)
            endoflist = endoflist.next;
        while (endoflist.getDay() == day)
        {
            if(endoflist.getDay() != day )
                break;
            endoflist.printEx();
            endoflist = endoflist.next;
            if( endoflist.next == null) {
                endoflist.printEx();
                break;
            }
        }
    }

    /**
     *
     * @param day delete all experiment in this day.
     */
    public void removeDay(int day) // remove all experiments in a given day
    {
        boolean found = false;
        endoflist = head;
        endoflisttemp = head;

        try
        {
            while(endoflist.next != null) {
                if(endoflist.getDay() == day)
                    found = true;
                endoflist = endoflist.next;
            }
            if (!found) {
                System.out.println("This Day Not Found.");
                throw new NoSuchElementException();
            }
        }catch (Exception e)
        {
            System.out.println("This Day Not Found.");
            exit(1);
        }
        endoflist = head;
        while (endoflist.next.getDay() < day )
        {
            endoflist = endoflist.next;
        }
        while ((endoflisttemp.getDay() < day+1))
            endoflisttemp = endoflisttemp.next;
        endoflist.next = endoflisttemp;

    }

    /**
     *
     * @param day order all experiment in this day.
     */
    public void orderDay(int day) // sorts the experiments in a given day according to the accuracy, the changes will be done on the list
    {
        Experiment first = head;
        boolean found = false;
        int size=0;
        endoflist = head;
        while (endoflist.next != null)
        {
            if(endoflist.getDay() == day) {
                size++;
                found = true;
                break;
            }
            first = endoflist;
            endoflist = endoflist.next;
        }
        if(!found)
        {
            System.out.println("gün bulunamadı.");
            exit(1);
        }
        endoflisttemp = endoflist;
        while (endoflist.next != null)
        {
            if(endoflist.next.getDay() != day)
                break;
            endoflist = endoflist.next;
            size++;
        }

        Experiment [] exarr = new Experiment[size];
        //for (int i=0; i < size; i++)
            //exarr[i] = new Experiment();

        int j=0;
        for (j = 0; j < size; j++)
        {
            //endoflisttemp.printEx();
            exarr[j] = new Experiment(endoflisttemp);
            endoflisttemp = endoflisttemp.next;
        }


        Experiment temp=null;
        boolean isswap = false;
        for (int i = 0; i < size - 1; i++)
        {
            isswap = false;
            for (j = 0; j < size - i - 1; j++)
            {
                if (exarr[j].getAccuracy() > exarr[j + 1].getAccuracy())
                {
                    temp = exarr[j];
                    exarr[j] = exarr[j + 1];
                    exarr[j + 1] = temp;
                    isswap = true;
                }
            }
            if (!isswap)
                break;
        }

        if(first == head)
        {
            for (j = 0; j < size; j++)
            {
                first = exarr[j];
                first = first.next;
            }
        }
        else {
            for (j = 0; j < size; j++) {
                first.next = exarr[j];
                first = first.next;
            }
            if(first.next != null )
                first.next = endoflisttemp.next;
        }

    }

    /**
     *  sorts all the experiments in the list according to the accuracy,
     *  the original list should not be changed since the day list may be damage
     * @return retrurn erdered experiment head.
     */

    public Experiment orderExperiments() {

        boolean isswap = false;
        endoflist = head;
        int size=0;
        while(endoflist != null) {
            size++;
            endoflist = endoflist.next;
        }
        endoflist = head;
        endoflisttemp = endoflist;

        Experiment [] exarr = new Experiment[size];

        int j=0;
        for (j = 0; j < size; j++)
        {
            //endoflisttemp.printEx();
            exarr[j] = new Experiment(endoflisttemp);
            endoflisttemp = endoflisttemp.next;
        }

        Experiment temp=null;
        for (int i = 0; i < size - 1; i++)
        {
            isswap = false;
            for (j = 0; j < size - i - 1; j++)
            {
                if (exarr[j].getAccuracy() > exarr[j + 1].getAccuracy())
                {
                    temp = exarr[j];
                    exarr[j] = exarr[j + 1];
                    exarr[j + 1] = temp;
                    isswap = true;
                }
            }
            if (!isswap)
                break;
        }


        for (j=0;j<size-1;j++)
        {
            exarr[j].next = exarr[j+1];
        }
        exarr[size-1].next = null;

        Experiment ret = new Experiment(exarr[0]);
        
        System.out.println();
        return ret;
    }

    /***
     * print the linked list. from head to tail
     */
    public void printList()
    {
        Experiment th = head;
        while(th.next != null)
        {
            th.printEx();
            th = th.next;
        }
        th.printEx();

    }
    @Override
    public Iterator<Experiment> iterator() {
        Iterator<Experiment> iter = new Iterator<Experiment>() {
            private Experiment iterator = head;

            @Override
            public boolean hasNext() {
                if(iterator.next != null) return true;
                else return false;
            }

            @Override
            public Experiment next() {
                iterator = iterator.next;
                return iterator;
            }

        };
        return iter;
    }
}


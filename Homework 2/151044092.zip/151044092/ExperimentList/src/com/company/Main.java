package com.company;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

public class Main {

    public static void main(String[] args) {

        DateFormat dateFormat = new SimpleDateFormat("hh:mm:ss");
        Date date = new Date();
        String time=dateFormat.format(date);

        ExperimentList ExpListe = new ExperimentList();
        Experiment ordered;


        ExpListe.addExp(new Experiment("Exp1",1,time,false,54));
        ExpListe.addExp(new Experiment("Exp2",1,time,false,12));
        ExpListe.addExp(new Experiment("Exp3",1,time,false,17));
        ExpListe.addExp(new Experiment("Exp1",2,time,false,28));
        ExpListe.addExp(new Experiment("Exp2",2,time,false,21));
        ExpListe.addExp(new Experiment("Exp1",3,time,false,9));
        ExpListe.addExp(new Experiment("Exp2",3,time,false,8));
        ExpListe.addExp(new Experiment("Exp1",4,time,false,78));
        ExpListe.addExp(new Experiment("Exp2",4,time,false,37));
        ExpListe.addExp(new Experiment("Exp3",4,time,false,4));
        ExpListe.addExp(new Experiment("Exp1",6,time,false,41));
        ExpListe.addExp(new Experiment("Exp1",7,time,false,86));
        ExpListe.addExp(new Experiment("Exp2",7,time,false,58));

        System.out.println("This is First List: ");
        ExpListe.printList();
        System.out.println();

        Experiment set1 = new Experiment("ExpSET", 2,time, true, 44);
        System.out.println("Set Expertion. Set day 2, index 1.");
        ExpListe.setExp(2,1,set1);
        ExpListe.printList();
        System.out.println();

        System.out.println("Get Experition. Get day 4 and index 2.");
        ExpListe.getExp(4,2);
        System.out.println();

        System.out.println("Remove Experiton. Remove day 2, index 1.(seted exp).");
        ExpListe.removeExp(4,3);
        ExpListe.printList();
        System.out.println();

        System.out.println("Remove Day. Remove day 2.");
        ExpListe.removeDay(2);
        ExpListe.printList();
        System.out.println();

        System.out.println("ListExpertions. Show the given day experiments.");
        ExpListe.listExp(4);
        System.out.println();

        System.out.println("Order Day. Order the 7st day experition.");
        ExpListe.orderDay(4);
        ExpListe.printList();
        System.out.println();

        System.out.println("Order Experiment. Order all experiment according to the accuracy.");
        Experiment orderedEx = ExpListe.orderExperiments();

        while(orderedEx.next != null)
        {
            System.out.println(orderedEx.toString());
            orderedEx = orderedEx.next;
        }


        Iterator iter = ExpListe.iterator();
        while(iter.hasNext()) {
            System.out.println(iter.next());
        }



    }
}
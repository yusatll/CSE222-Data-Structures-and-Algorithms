import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class NLP
{
    public Word_Map wmap;

    NLP(){
        wmap = new Word_Map();
    }
    /*You should not use File_Map class in this file since only word hash map is aware of it.
    In fact, you can define the File_Map class as a nested class in Word_Map,
     but for easy evaluation we defined it separately.
     If you need to access the File_Map instances, write wrapper methods in Word_Map class.
    * */

    /*Reads the dataset from the given dir and created a word map */
    public void readDataset(String dir) throws IOException
    {
        String allText;
        File fileDir = new File(dir);
        File[] files = fileDir.listFiles();

        for(File f: files)
        {
            try (BufferedReader BR = new BufferedReader(new FileReader(f)))
            {
                StringBuilder SB = new StringBuilder();
                String line = BR.readLine();

                while (line != null)
                {
                    line = line.trim().replaceAll("\\p{Punct}", "").replaceAll("\n","");
                    SB.append(line);
                    SB.append(System.lineSeparator());
                    line = BR.readLine();
                }
                allText = SB.toString();
            }

            File_Map fm = new File_Map();
            String[] fileText = allText.split(" ");

            for (int i = 0; i < fileText.length; i++)
            {
                for (int j = 1; j < fileText.length - i; j++)
                {

                    if (fileText[i].equals(fileText[j]))
                    {
                        List<Integer> jL = fm.occurances.get(i);

                        if(jL == null)
                        {
                            jL = new ArrayList<>();
                            jL.add(j);
                            fm.occurances.add(jL);
                        }
                        else
                        {
                            jL.add(j);
                        }
                    }
                }
                wmap.put(fileText[i],fm);
                break;
            }

            for (int i = 0; i < fileText.length; i++) {
                System.out.println(fileText[i] + " " + f.getName());

            }

        }

        printWordMap();

    }

    public List<String> bigrams(String word)
    {
        return null;
    }


    /*Calculates the tfIDF value of the given word for the given file */
    public float tfIDF(String word, String fileName)
    {
        return 0f;
    }

    /*Print the WordMap by using its iterator*/
    public  void printWordMap()
    {
        //wmap.print();
    }

}

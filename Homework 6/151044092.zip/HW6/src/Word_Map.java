import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Word_Map implements Map, Iterable
{

    final static int INITCAP=100;  //initial capacity
    int CURRCAP = INITCAP;   //current capacity
    final static float LOADFACT = 0.75f;
    private Node table[];
    private final Node NullNode = new Node(null,null);
    private int numberKey;
    private int deletedKey = 0;

    public Word_Map() {
        this.table = new Node[INITCAP];
//        for (int i = 0; i < INITCAP; i++) {
//            table[i] =  new Node();
//        }
    }

    @Override
    public Iterator iterator() {
        Iterator iter = new Iterator() {
            int index = this.hashCode() % CURRCAP;
            @Override
            public boolean hasNext() {
                return table[++index] != null;
            }

            @Override
            public Object next() {
                if (this.hasNext())
                    return table[++index];
                else
                    return null;
            }
        };
        return iter;
    }

    static class Node {
        // complete this class according to the given structure in homework definition
        Node(){}
        Node(Object k, Object v){
            word = (String) k;
            fileMap = (File_Map) v;
        }
        private String  word;
        public File_Map fileMap;
        public Node nextNode;

        public String getWord() {
            return word;
        }
    }


    @Override
    public int size() {
        return numberKey;
    }

    @Override
    public boolean isEmpty() {
        return numberKey == 0;
    }

    @Override
    /*Use linked structure instead of table index
    to perform search operation effectively
     * */
    public boolean containsKey(Object key) {
        int in = find(key);
        if (in == table.length)
            return false;
        return true;
    }

    @Override
    /*Use linked structure instead of table index
    to perform search operation effectively
     * */
    public boolean containsValue(Object value) {
        int index = find(value);
        if (table[index].fileMap.get(index) != null)
            return true;
        return false;
    }

    @Override
    public Object get(Object key) {
        int index = find(key);
        if (table[index] != null)
            return table[index].fileMap.get(index);
        else return null;
    }


    @Override
    /*
    Use linear probing in case of collision
    * */
    public Object put(Object key, Object value)
    {
        int index = find(key);
        if (table[index] == null)
        {
            table[index] = new Node(key,value);
            numberKey++;
            double loadFactor = (double) (numberKey + deletedKey) / CURRCAP;
            if (loadFactor > LOADFACT)
                rehash();

            return null;
        }

        File_Map oldVal = table[index].fileMap;
        table[index].word = (String) key;
        table[index].fileMap = (File_Map) value;
        return oldVal;
    }



    private void rehash()
    {
        Node[] old = table;
        table = new Node[2*CURRCAP+1];
        numberKey = 0;
        deletedKey = 0;

        for (int i= 0; i < old.length; i++)
        {
            if ((old[i] != null) && (old[i] != NullNode)) {
                put(old[i].word, old[i].fileMap);
            }
        }
    }

    private int find(Object key)
    {
        int index = key.hashCode() % CURRCAP;

        if (index < 0)
            index += CURRCAP;

        while (table[index] != null && !(key.equals(table[index].word)))
        {
            index++;
            if (index >= CURRCAP)
                index = 0;
        }
        return index;
    }

    protected void print()
    {
        for (int i = 0; i < table.length; i++) {
            table[i].fileMap.print();
        }
    }

    @Override
    /*You do not need to implement remove function
    * */
    public Object remove(Object key) {
        return null;
    }

    @Override
    public void putAll(Map m) {

    }

    @Override
    public void clear() {
        table = new Node[INITCAP];
        numberKey = 0;
        deletedKey = 0;
    }

    @Override
    /*Use linked structure instead of table index
    for efficiency
     * */
    public Set keySet() {
        return null;
    }

    @Override
    /*Use linked structure instead of table index
    for efficiency
     * */
    public Collection values() {
        return null;
    }

    @Override
    /*You do not need to implement entrySet function
     * */
    public Set<Entry> entrySet() {
        return null;
    }
}

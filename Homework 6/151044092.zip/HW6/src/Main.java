import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Main {
    public static void main(String[] args) throws IOException {

        NLP n = new NLP();
        n.readDataset("dataset");

        BufferedReader br = new BufferedReader(new FileReader("src/input.txt"));
        try
        {
            String line = br.readLine();

            while (line != null)
            {
                String[] s = line.split(" ");
                if(s[0].equals("bigram"))
                    System.out.println("Bigram function is not implement.");
                else if(s[0].equals("tfidf"))
                    System.out.println("TFIDF not working.");
                line = br.readLine();
            }

        }
        finally {
            System.out.println("\nI only fill the wmap and its file map.\nI did not" +
                    " implement bigram and TFIDF functions. \nOnly implement wordmap and " +
                    "file map functions.");
            br.close();
        }




    }

}

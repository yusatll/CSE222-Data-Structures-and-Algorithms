import java.util.*;

public class File_Map implements Map
{
    /*
    For this hashmap, you will use arraylists which will provide easy but costly implementation.
    You should provide and explain the complexities for each method in your report.
    * */
    ArrayList<String> fnames;
    ArrayList<List<Integer>> occurances;

    final static int INITCAP=100;  //initial capacity
    int CURRCAP = INITCAP;   //current capacity
    final static float LOADFACT = 0.75f;
    private int numberKey;
    private int deletedKey;
    final private String removedStr = "!ReMoVeD-/*";


    File_Map()
    {
        fnames = new ArrayList<>(INITCAP);
        occurances = new ArrayList<>(INITCAP);
        for (int i=0; i < INITCAP; i++) {
            fnames.add(null);
            occurances.add(null);
        }

    }

    @Override
    public int size() {
        return occurances.size();
    }

    @Override
    public boolean isEmpty() {
        return occurances.size() == 0;
    }

    @Override
    public boolean containsKey(Object key) {
        for (String fname : fnames) {
            if (fname.equals(key))
                return true;
        }
        return false;
    }

    @Override
    public boolean containsValue(Object value) {
        for (List<Integer> occurance : occurances) {
            if (occurance.equals(value))
                return true;
        }
        return false;
    }

    @Override
    public Object get(Object key) {
        int index = fnames.indexOf(key);
        return occurances.get(index);
    }

    @Override
    /*Each put operation will extend the occurance list*/
    /* sadece int degerleri ekleyecegiz. filename ekleme. */
    public Object put(Object key, Object value) {
        int index;
        List<Integer> a = null;
        if (!(fnames.equals(key)))
            fnames.add((String) key);
        else
        {
            index = fnames.indexOf(key);
            a = occurances.get(index);
            occurances.get(index).add((Integer) value);
        }

        return a;

//          hash map hali
//        int index = find(key);
//        if (fnames.get(index) == null)
//        {
//            numberKey++;
//
//            double loadFactor = (numberKey + deletedKey) / CURRCAP;
//            if (loadFactor > LOADFACT)
//                rehash();
//
//            return null;
//        }
//
//        List<Integer> old = occurances.get(index);
//        occurances.get(index).set(index, (Integer) value);
//        return  old;



    }



    @Override
    public Object remove(Object key) {
        int index = fnames.indexOf(key);
        List<Integer> removedVal = new ArrayList<>();
        fnames.set(index,removedStr);
        occurances.set(index,removedVal);
        return null;
    }

    @Override
    public void putAll(Map m) {
//        Object obj =  m.keySet();
//        for(Object o : obj) {
//            put(o,m.get(o));
//        }

        for (int i = 0; i < m.size(); i++)
        {
            fnames.add((String) m.get(i));
            occurances.add((List<Integer>) m.get(i));
        }
    }

    public void print() {
        for (int i=0; i < fnames.size(); i++) {
            System.out.println(fnames.get(i) +" " + occurances.get(i));

        }
    }

    @Override
    public void clear() {
        fnames.clear();
        occurances.clear();
    }

    @Override
    public Set keySet() {
        Set<String> setKeys = new HashSet<>();
        String f;
        int i=0;
        while (i<CURRCAP) {
            if ((f = fnames.get(i)) != null)
                setKeys.add(f);
            i++;
        }
        return setKeys;
    }

    @Override
    public Collection values() {
        return null;
    }

    @Override
    public Set<Entry> entrySet() {
        Set<Entry> setVal = new HashSet<>();
        String v;
        int i = 0;
        while (i < CURRCAP)
        {
            if ((v = fnames.get(i)) != null)
                setVal.add(new AbstractMap.SimpleEntry<>(fnames,v));
            i++;
        }
        return setVal;
    }

}
